Drew Remmenga
About four hours was spent on this project with assistance from Krisitn Farris in debugging.
I struggled to determine the source of varius bugs. 